import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import '../src/style.css';

import Contactus from './pages/Contactus';
import Home from './pages/Home';
import Login from './pages/Login';
import Cart from './pages/Cart';
import Navbar from './component/Navbar';
import Footer from './component/Footer';

// products
import AllProduct from './pages/product/AllProduct';
import Allwomen from './pages/product/Allwomen';
import Allmen from './pages/product/Allmen';
import Pents from './pages/product/Pents';
import Kurta from './pages/product/Kurta';
import Saree from './pages/product/Saree';
import Skirt from './pages/product/Skirt';
import Shirt from './pages/product/Shirt';
import Hoodies from './pages/product/Hoodies';
import Kids from './pages/product/Kids';
function App() {
  return (
    
    <Router>
      <Navbar></Navbar>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/contactus" element={<Contactus />} />
        <Route path="/allproduct" element={<AllProduct />} />
        <Route path="/allmen" element={<Allmen />} />
        <Route path="/allwomen" element={<Allwomen />} />
        <Route path="/pents" element={<Pents />} />
        <Route path="/kurta" element={<Kurta />} />
        <Route path="/saree" element={<Saree />} />
        <Route path="/skirt" element={<Skirt />} />
        <Route path="/shirt" element={<Shirt />} />
        <Route path="/hoodies" element={<Hoodies />} />
        <Route path="/kids" element={<Kids />} />
      </Routes>
      <Footer></Footer>
    </Router>
  );
}

export default App;
