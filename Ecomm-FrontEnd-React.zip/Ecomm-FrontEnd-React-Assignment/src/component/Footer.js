import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
function Footer() {
  return (
    <Fragment>
        <footer className="footer" >
        <div className="container">
            <br/>
            <div className="row">
                <div className="col-sm">
                    <h5>Women</h5>
                    <Link to="/Saree"><h className="footerlink">Saree</h></Link>
                    <Link to="/Kurta"><h className="footerlink">Kurta</h></Link>
                    <Link to="/Skirt"><h className="footerlink">Skirts</h></Link>
                </div>
                <div className="col-sm">
                    <h5>Men</h5>
                    <Link to="/Shirt"><h className="footerlink">Shirts</h></Link>
                    <Link to="/Pents"><h className="footerlink">Pants</h></Link>
                    <Link to="/Hoodies"><h className="footerlink">Hoodies</h> </Link>
                </div>
                <div className="col-sm">
                    <h5>Kids</h5> 
                    <Link to="/Kids"><h className="footerlink">All</h></Link>
                </div>
                <div className="col-sm">
                    <h5>links</h5>
                    <Link to="/"><h className="footerlink">Home</h></Link>
                    <Link to="/Login"><h className="footerlink">Login</h></Link>
                    <Link to="/Contactus"><h className="footerlink">Contact</h> </Link>
                </div>
            </div>
            <hr/>
            <div className="col"><h6>Copyright©Ecommerce 2022-23</h6></div>
            <br/>
        </div>
    </footer>
    </Fragment>
  )
}

export default Footer