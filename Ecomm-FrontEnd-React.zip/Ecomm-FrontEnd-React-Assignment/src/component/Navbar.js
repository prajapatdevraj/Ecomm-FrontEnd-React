import React, { Fragment } from 'react'
import logo from '../images/Smart_choice_logo.png'
import { Link } from 'react-router-dom';

function Navbar() {
    return (
        <Fragment>
            {/* <!-- First Navbar with External CSS --> */}
            <nav className="navbar first-nav">
                {/* <!-- logo --> */}
                <Link to="/" className="logo">
                    <img src={logo} alt="SmartChoice_Logo"
                        style={{ width: "171px", height: "57px", marginInlineStart: "10px" }} />
                </Link>
                {/* <!-- search bar --> */}
                <div className="item search right">
                    <div className="search-group">
                        <input type="text" placeholder="    search" />
                        {/* <!--search icon  --> */}
                        <span className="material-symbols-outlined search-icon" style={{ fontSize: "2rem" }}>search</span>
                    </div>
                </div>
                {/* <!-- login button --> */}
                <Link to="/login" className="btn item login_out">
                    <div className="login_in">
                        <span className="material-symbols-outlined">
                            login
                        </span>
                        <div className="detail">
                            Login
                        </div>
                    </div>
                </Link>
                {/* <!-- Shopping Cart --> */}
                <Link to="/cart" className="cart">
                    <span className="material-symbols-outlined" style={{ fontSize: "2rem" }}>
                        shopping_cart
                    </span>
                </Link>
                
            </nav>
            {/* <!-- Second Navbar with inline CSS --> */}
            <nav className="second-nav" style={{ backgroundColor: "rgb(255 243 190)", display: "flex", justifyContent: "center" }}>
                <ul className="nav nav-pills">
                    {/* <!-- home --> */}
                    <li className="nav-item">
                        <Link className="nav-link" to="/">Home</Link>
                    </li>
                    {/* <!-- all product --> */}
                    <li className="nav-item">
                        <Link className="nav-link" to="/allproduct">All Products</Link>
                    </li>
                    {/* <!-- women dropdown --> */}
                    <li className="nav-item dropdown">
                        <Link className="nav-link dropdown-toggle" data-bs-toggle="dropdown" to='...'>Women</Link>
                        <ul className="dropdown-menu" style={{ backgroundColor: "rgb(255 243 190)" }}>
                            <li className="dropdown-item"><Link to="/Allwomen">All</Link></li>
                            <li className="dropdown-item"><Link to="/Saree">Saree</Link></li>
                            <li className="dropdown-item"><Link to="/Kurta">Kurta</Link></li>
                            <li className="dropdown-item"><Link to="/Skirt">Skirts</Link></li>
                        </ul>
                    </li>
                    {/* <!-- men dropdown --> */}
                    <li className="nav-item dropdown">
                        <Link className="nav-link dropdown-toggle" data-bs-toggle="dropdown" to='...'>Men</Link>
                        <ul className="dropdown-menu" style={{ backgroundColor: "rgb(255 243 190)" }}>
                            <li className="dropdown-item"><Link to="/Allmen">All</Link></li>
                            <li className="dropdown-item"><Link to="/Shirt">Shirts</Link></li>
                            <li className="dropdown-item"><Link to="/Pents">Pants</Link></li>
                            <li className="dropdown-item"><Link to="/Hoodies">Hoodies</Link></li>
                        </ul>
                    </li>
                    {/* <!-- contact  --> */}
                    <li className="nav-item">
                        <Link className="nav-link" to="/kids">Kids</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/contactus">Contact</Link>
                    </li>
                </ul>
            </nav>
        </Fragment>
    )
}

export default Navbar