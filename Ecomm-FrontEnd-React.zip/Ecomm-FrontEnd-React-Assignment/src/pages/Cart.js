import React, { Fragment } from 'react'
import cartimg from '../images/Product/Women-Saree/cart image.jpg'

function Cart() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
        
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Cart</h2>
    <br/>
    
    <div className="container-fluid d-flex justify-content-center  mb-5 ">
        <div className="row">
            {/* <!-- card for item in cart --> */}
            <div className="col-lg col-md col-sm-8  " style={{textAlign: "center", minWidth:"500px"}}>
                <div className="card">
                    <h5 className="card-header" style={{textAlign: "center"}}>Items in cart</h5>
                    <div className="card-body">
                      <div className="row">
                        <img className="col-4" src={cartimg} alt="..."></img>
                        
                        <div className="col-4">
                            <h5>Royal Saree</h5>
                            <br></br>
                            <div>$15</div>
                            <br></br>
                            <button className="btn btn-warning"><span className="material-symbols-outlined">
                                delete
                                </span></button>
                        </div>
                        <div className="col-4">
                            <div className="row">
                                <div className="cartBtn col-sm col-md"><button id="subBtn" className="btn btn-warning" onclick="sub()" ><span className="material-symbols-outlined">
                                    remove
                                    </span></button></div>
                                <div className="cartBtn col-sm col-md"><input id="displayCount" type="number" value="0" style={{maxWidth:"50px"}}></input></div>
                                <div className="cartBtn col-sm col-md"><button id="addBtn" className="btn btn-warning" onclick="add()"><span className="material-symbols-outlined">
                                    add
                                    </span></button></div>
                                
                            </div>
                            
                            
                            
                        </div>
                      </div>
                    </div>
                  </div>
            </div>
            {/* <!-- card for summary --> */}
            <div className="col-lg-4 col-md col-sm-8">
                <div className="card" style={{textAlign: "center"}}>
                    <h5 className="card-header" >Summary</h5>
                    <div className="card-body">
                      <div className="row">
                        <div className="col" style={{textAlign:"start"}}>Cost</div>
                        <div className="col" style={{textAlign: "end"}}>$15</div>
                      </div>
                      <div className="row">
                        <div className="col" style={{textAlign:"start"}}>Shipping</div>
                        <div className="col" style={{textAlign: "end"}}>$5</div>
                      </div>
                      <hr></hr>
                      <div className="row">
                        <div className="col" style={{textAlign: "start", fontWeight: "bold"}}>Total</div>
                        <div className="col" style={{textAlign: "end", fontWeight: "bold"}}>$20</div>
                      </div>
                      <button className="btn btn-warning">Checkout</button>
                    </div>
                  </div>
            </div>

        </div>

    </div>
    
    </Fragment>
  )
}

export default Cart