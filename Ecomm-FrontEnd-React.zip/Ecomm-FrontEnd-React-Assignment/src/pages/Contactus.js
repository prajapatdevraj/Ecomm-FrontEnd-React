import React, { Fragment } from 'react'
import contactus from '../images/contactus/contactusPic.avif'

function Contactus() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Contact Us</h2>
    <br/>
    <div class="container mb-5">
        <div class="row" style={{marginBottom: "50px"}}>
            {/* <!-- column 1 --> */}
            <div class="col-sm-6">
                {/* <!--Image =class img-fluid is used to make image responsive--> */}
                <img src={contactus} class="img-fluid" alt="contimg"/>
            </div>
            {/* <!-- column 1 --> */}
            <div class="col-sm-6">
                {/* <!-- Form --> */}
                <form class="form">
                    <label class="form-label">Name :</label>
                    <input type="text" class="form-control" placeholder="Enter your name"/>
                    <label class="form-label">E-mail:</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your E-mail"/>
                    <label class="form-label">Message:</label>
                    <textarea type="text" class="form-control" placeholder="Enter your message"></textarea>
                    <br/>
                    {/* <!-- submit button --> */}
                    <input type="button" class="btn"
                        style={{width: "100%", backgroundColor:"rgb(255, 215, 0)", fontWeight: "bold"}} value="Submit"/>
                </form>
            </div>
        </div>
    </div>

    </Fragment>
  )
}

export default Contactus