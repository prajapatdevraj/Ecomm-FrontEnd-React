import React, { Fragment } from 'react'
import homebackground from '../images/home-background.png'
import saree1 from '../images/Product/Women-Saree/saree (14).webp'
import saree2 from '../images/Product/Women-Saree/saree (1).webp'
import saree3 from '../images/Product/Women-Saree/saree (6).webp'
import saree4 from '../images/Product/Women-Saree/saree (5).webp'
import saree5 from '../images/Product/Women-Saree/saree (3).webp'
import kurta1 from '../images/Product/women-kurta/kurta (1).webp'
import kurta2 from '../images/Product/women-kurta/kurta (2).webp'
import kurta3 from '../images/Product/women-kurta/kurta (5).webp'
import kurta4 from '../images/Product/women-kurta/kurta (3).webp'
import kurta5 from '../images/Product/women-kurta/kurta (4).webp'
import shirt1 from '../images/Product/Men-Shirts/shirt (1).webp'
import shirt2 from '../images/Product/Men-Shirts/shirt (5).webp'
import shirt3 from '../images/Product/Men-Shirts/shirt (2).webp'
import shirt4 from '../images/Product/Men-Shirts/shirt (3).webp'
import shirt5 from '../images/Product/Men-Shirts/shirt (4).webp'

function Home() {
  return (
    <Fragment>
            {/* <!-- mid --> */}
    <div className="mid">
        <img alt='homebackground' src={homebackground} style={{width:"100%"}}/>
        
    </div>

    {/* <!--Carousel Slider for large medium and small screen  --> */}
    <div style={{backgroundColor:"rgb(216, 208, 173)"}}>
        <div className="container">
            <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Featured Products</h2>
            {/* <!-- for large screen --> */}
            <div id="largeScreencarousel" className="carousel carousel-dark slide d-none d-md-none d-lg-block">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={saree1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree4} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree5} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={kurta1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta4} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta5} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={shirt1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt4} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt5} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#largeScreencarousel"
                    data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#largeScreencarousel"
                    data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>
            {/* <!-- for medium screen --> */}
            <div id="mediumScreencarousel" className="carousel carousel-dark slide d-none d-md-block d-lg-none">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={saree1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={kurta1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={shirt1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt3} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#mediumScreencarousel"
                    data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#mediumScreencarousel"
                    data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>
            {/* <!-- for small screen --> */}
            <div id="smallScreencarousel" className="carousel carousel-dark slide d-block d-md-none d-lg-none">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={saree1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={saree2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={kurta1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={kurta2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="carousel-item">
                        <div className="cards-wrapper">
                            <div className="card">
                                <img src={shirt1} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>
                            <div className="card">
                                <img src={shirt2} className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h3>Product</h3>
                                    <h5>$20</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    <button className="btn btn-warning"><span
                                            className="material-symbols-outlined">shopping_cart</span> Add
                                        to cart</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#smallScreencarousel"
                    data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#smallScreencarousel"
                    data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>


            {/* <!-- this is how code is sellected according to screen using class -->
            <!-- <div className="d-none d-md-none d-lg-block" style="background-color: aqua;"><h>large</h> </div> 
        <div className=" d-none d-md-block d-lg-none" style="background-color: darkblue;"><h>Medium</h> </div>
        <div className="d-block d-md-none d-lg-none" style="background-color: hotpink"><h>large</h> </div> --> */}



        </div>
    </div>
    </Fragment>
  )
}

export default Home