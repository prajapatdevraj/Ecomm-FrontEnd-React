import React, { Fragment } from 'react'

function Login() {
 return (
    <Fragment>
            {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Login</h2>
    <br/>
    <div className="container-sm " style={{maxWidth:"500px", marginBottom: "150px"}} >
        {/* <!-- Form --> */}
        <form  className="form">
            {/* <!-- Input Email --> */}
            <label className="form-label">E-mail:</label>
            <input type="email" name="email" className="form-control" placeholder="Enter your E-mail" id="inputMail" ></input>
            {/* <!-- Input Password --> */}
            <label className="form-label">Password:</label>
            <input type="password" className="form-control" placeholder="Enter your Password" id="inputPassword"></input>
            <br/>
            {/* <!-- Login button --> */}
            <input type="button" className="btn" onclick="check()" style={{width: "100%", backgroundColor:"rgb(255, 215, 0)", fontWeight: "bold"}} value="Login"></input>
        </form>
    </div>

    </Fragment>
  )
}

export default Login