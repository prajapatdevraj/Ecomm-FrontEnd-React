import React, { Fragment } from 'react'
import Hoodies from './Hoodies'
import Saree from './Saree'
import Kids from './Kids'
import Kurta from './Kurta'

import Pents from './Pents';
import Skirt from './Skirt';
import Shirt from './Shirt';
function AllProduct() {
  return (
    <Fragment>
        
        <Hoodies></Hoodies>
        <Shirt></Shirt>
        <Pents></Pents>
        <Kurta></Kurta>
        <Saree></Saree>
        <Skirt></Skirt>
        <Kids></Kids>
    </Fragment>
  )
}

export default AllProduct