import React, { Fragment } from 'react'
import Hoodies from './Hoodies'
import Shirt from './Shirt'
import Pents from './Pents'

function Allmen() {
  return (
    <Fragment>
        <Hoodies></Hoodies>
        <Shirt></Shirt>
        <Pents></Pents>
    </Fragment>
  )
}

export default Allmen