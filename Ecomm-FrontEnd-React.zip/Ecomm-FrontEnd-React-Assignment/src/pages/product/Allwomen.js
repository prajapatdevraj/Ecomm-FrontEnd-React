import React, { Fragment } from 'react'
import Saree from './Saree'
import Skirt from './Skirt'
import Kurta from './Kurta'

function Allwomen() {
  return (
    <Fragment>
        <Saree></Saree>
        <Skirt></Skirt>
        <Kurta></Kurta>
    </Fragment>
  )
}

export default Allwomen