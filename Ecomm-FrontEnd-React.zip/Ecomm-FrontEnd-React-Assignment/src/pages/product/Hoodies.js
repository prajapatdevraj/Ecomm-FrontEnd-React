import React, { Fragment } from 'react'
import hoodie1 from '../../images/Product/Men-Hoodies/Hoodies (1).webp'
import hoodie2 from '../../images/Product/Men-Hoodies/Hoodies (2).webp'
import hoodie3 from '../../images/Product/Men-Hoodies/Hoodies (3).webp'
import hoodie4 from '../../images/Product/Men-Hoodies/Hoodies (4).webp'
import hoodie5 from '../../images/Product/Men-Hoodies/Hoodies (5).webp'
import hoodie6 from '../../images/Product/Men-Hoodies/Hoodies (6).webp'
import hoodie7 from '../../images/Product/Men-Hoodies/Hoodies (7).webp'
import hoodie8 from '../../images/Product/Men-Hoodies/Hoodies (8).webp'
import hoodie9 from '../../images/Product/Men-Hoodies/Hoodies (9).webp'
import hoodie10 from '../../images/Product/Men-Hoodies/Hoodiesjpeg (1).jpeg'
import hoodie11 from '../../images/Product/Men-Hoodies/Hoodiesjpeg (2).jpeg'
import hoodie12 from '../../images/Product/Men-Hoodies/Hoodiesjpeg (3).jpeg'

function Hoodies() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Hoodies</h2>

    <div className="container productCard">
        {/* <!-- row 1 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie1} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie2} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie3} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie4} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie5} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie6} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 2 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie7} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie8} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie9} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie10} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie11} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie12} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 3 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie3} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie5} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie9} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie2} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie7} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{ textAlign: "center"}}>
                    <img className="card-img-top" src={hoodie10} alt="Cardimage"/>
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    </Fragment>
  )
}

export default Hoodies