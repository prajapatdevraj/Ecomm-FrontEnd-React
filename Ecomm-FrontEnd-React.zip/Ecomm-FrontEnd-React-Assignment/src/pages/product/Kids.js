import React, { Fragment } from 'react'
import kids1 from '../../images/Product/Kids/Kids (1).webp'
import kids2 from '../../images/Product/Kids/Kids (2).webp'
import kids3 from '../../images/Product/Kids/Kids (3).webp'
import kids4 from '../../images/Product/Kids/Kids (4).webp'
import kids5 from '../../images/Product/Kids/Kids (5).webp'
import kids6 from '../../images/Product/Kids/Kids (6).webp'
import kids7 from '../../images/Product/Kids/Kids (7).webp'
import kids8 from '../../images/Product/Kids/Kids (8).webp'
import kids9 from '../../images/Product/Kids/Kids (9).webp'
import kids10 from '../../images/Product/Kids/Kids (10).webp'
import kids11 from '../../images/Product/Kids/Kids (11).webp'
import kids12 from '../../images/Product/Kids/Kids (12).webp'

function Kids() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Kids</h2>

    <div className="container productCard">
        {/* <!-- row 1 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids1} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids2} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids3} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids4} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids5} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids6} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 2 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids7} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids8} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids9} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids10} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids11} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids12} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 3 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids4} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids1} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids5} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids12} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids11} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={kids9} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </Fragment>
  )
}

export default Kids