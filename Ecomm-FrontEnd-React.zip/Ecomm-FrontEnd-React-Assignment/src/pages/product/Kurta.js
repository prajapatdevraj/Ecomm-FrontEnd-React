import React, { Fragment } from 'react'
import kurta1 from '../../images/Product/women-kurta/kurta (1).webp'
import kurta2 from '../../images/Product/women-kurta/kurta (2).webp'
import kurta3 from '../../images/Product/women-kurta/kurta (3).webp'
import kurta4 from '../../images/Product/women-kurta/kurta (4).webp'
import kurta5 from '../../images/Product/women-kurta/kurta (5).webp'
import kurta6 from '../../images/Product/women-kurta/kurta (6).webp'
import kurta7 from '../../images/Product/women-kurta/kurta (7).webp'
import kurta8 from '../../images/Product/women-kurta/kurta (8).webp'
import kurta9 from '../../images/Product/women-kurta/kurta (9).webp'
import kurta10 from '../../images/Product/women-kurta/kurta (10).webp'
import kurta11 from '../../images/Product/women-kurta/kurta (11).webp'
import kurta12 from '../../images/Product/women-kurta/kurta (12).webp'
import kurta13 from '../../images/Product/women-kurta/kurta (13).webp'
import kurta14 from '../../images/Product/women-kurta/kurta (14).webp'
import kurta15 from '../../images/Product/women-kurta/kurta (15).webp'
import kurta16 from '../../images/Product/women-kurta/kurta (16).webp'
import kurta17 from '../../images/Product/women-kurta/kurta (17).webp'
import kurta18 from '../../images/Product/women-kurta/kurta (18).webp'
function Kurta() {
  return (
    <Fragment>
        <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Kurta</h2>

<div className="container productCard">
    {/* <!-- row 1 --> */}
    <div className="row">
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta1} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta2} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta3} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta4} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta5} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta6} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>

    </div>
    {/* <!-- row 2 --> */}
    <div className="row">
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta7} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta8} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta9} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta10} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta11} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta18} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>

    </div>
    {/* <!-- row 3 --> */}
    <div className="row">
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta12} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta13} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta14} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta15} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta16} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-6 col-lg-2">
            <div className="card" style={{textAlign: "center"}}>
                <img className="card-img-top" src={kurta17} alt="Cardimage" />
                <div className="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
    </div>
</div>
    </Fragment>
  )
}






export default Kurta