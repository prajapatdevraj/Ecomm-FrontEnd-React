import React, { Fragment } from 'react'
import pent1 from '../../images/Product/Men-Pents/pents (1).webp'
import pent2 from '../../images/Product/Men-Pents/pents (2).webp'
import pent3 from '../../images/Product/Men-Pents/pents (3).webp'
import pent4 from '../../images/Product/Men-Pents/pents (4).webp'
import pent5 from '../../images/Product/Men-Pents/pents (5).webp'
import pent6 from '../../images/Product/Men-Pents/pents (6).webp'
import pent7 from '../../images/Product/Men-Pents/pents (7).webp'
import pent8 from '../../images/Product/Men-Pents/pents (8).webp'
import pent9 from '../../images/Product/Men-Pents/pents (9).webp'

function Pents() {
  return (
    <Fragment>
        <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Pents</h2>

<div class="container productCard">
    {/* <!-- row 1 --> */}
    <div class="row">
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent1} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent2} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent3} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent4} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent5} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent6} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>

    </div>
    {/* <!-- row 2 --> */}
    <div class="row">
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent7} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent8} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent9} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent1} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent6} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent4} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>

    </div>
    {/* <!-- row 3 --> */}
    <div class="row">
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent2} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent7} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent9} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent4} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent8} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6 col-lg-2">
            <div class="card" style={{textAlign: "center"}}>
                <img class="card-img-top" src={pent2} alt="Cardimage" />
                <div class="card-body">
                    <h3>Product</h3>
                    <h5>$20</h5>
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                    <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                        to cart</button>
                </div>
            </div>
        </div>
    </div>
</div>
    </Fragment>
  )
}

export default Pents