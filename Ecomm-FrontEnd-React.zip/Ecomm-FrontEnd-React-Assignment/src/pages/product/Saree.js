import React, { Fragment } from 'react'
import saree1 from '../../images/Product/Women-Saree/saree (1).webp'
import saree2 from '../../images/Product/Women-Saree/saree (2).webp'
import saree3 from '../../images/Product/Women-Saree/saree (3).webp'
import saree4 from '../../images/Product/Women-Saree/saree (4).webp'
import saree5 from '../../images/Product/Women-Saree/saree (5).webp'
import saree6 from '../../images/Product/Women-Saree/saree (6).webp'
import saree7 from '../../images/Product/Women-Saree/saree (7).webp'
import saree8 from '../../images/Product/Women-Saree/saree (8).webp'
import saree9 from '../../images/Product/Women-Saree/saree (9).webp'
import saree10 from '../../images/Product/Women-Saree/saree (10).webp'
import saree11 from '../../images/Product/Women-Saree/saree (11).webp'
import saree12 from '../../images/Product/Women-Saree/saree (12).webp'
import saree13 from '../../images/Product/Women-Saree/saree (13).webp'
import saree14 from '../../images/Product/Women-Saree/saree (14).webp'
import saree15 from '../../images/Product/Women-Saree/saree (15).webp'
import saree16 from '../../images/Product/Women-Saree/saree (16).webp'
import saree17 from '../../images/Product/Women-Saree/saree (17).webp'
import saree18 from '../../images/Product/Women-Saree/saree (18).webp'
function Saree() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Saree</h2>

    <div class="container productCard">
        {/* <!-- row 1 --> */}
        <div class="row">
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree1} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree3} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree4} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree2} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree5} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree6} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 2 --> */}
        <div class="row">
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree7} alt="Cardimage" />
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree8} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree9} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree11} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree10} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree12} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 3 --> */}
        <div class="row">
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree13} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree14} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree15} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree16} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree17} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6 col-lg-2">
                <div class="card" style={{textAlign: "center"}}>
                    <img class="card-img-top" src={saree18} alt="Cardimage" />
                    <div class="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button class="btn btn-warning"><span class="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </Fragment>
  )
}

export default Saree