import React, { Fragment } from 'react'
import shirt1 from '../../images/Product/Men-Shirts/shirt (1).webp'
import shirt2 from '../../images/Product/Men-Shirts/shirt (2).webp'
import shirt3 from '../../images/Product/Men-Shirts/shirt (3).webp'
import shirt4 from '../../images/Product/Men-Shirts/shirt (4).webp'
import shirt5 from '../../images/Product/Men-Shirts/shirt (5).webp'
import shirt6 from '../../images/Product/Men-Shirts/shirt (6).webp'
import shirt7 from '../../images/Product/Men-Shirts/shirt (7).webp'
import shirt8 from '../../images/Product/Men-Shirts/shirt (8).webp'
import shirt9 from '../../images/Product/Men-Shirts/shirt (9).webp'
import shirt10 from '../../images/Product/Men-Shirts/shirt (10).webp'
import shirt11 from '../../images/Product/Men-Shirts/shirt (11).webp'
import shirt12 from '../../images/Product/Men-Shirts/shirt (12).webp'
import shirt13 from '../../images/Product/Men-Shirts/shirt (13).webp'
import shirt14 from '../../images/Product/Men-Shirts/shirt (14).webp'
import shirt15 from '../../images/Product/Men-Shirts/shirt (15).webp'
import shirt16 from '../../images/Product/Men-Shirts/shirt (16).webp'
import shirt17 from '../../images/Product/Men-Shirts/shirt (17).webp'
import shirt18 from '../../images/Product/Men-Shirts/shirt (18).webp'


function Shirt() {
    return (
        <Fragment>
            <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Shirt</h2>

            <div className="container productCard">
                {/* <!-- row 1 --> */}
                <div className="row">
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt1} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt2} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt3} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt4} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt5} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt6} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>

                </div>
                {/* <!-- row 2 --> */}
                <div className="row">
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt7} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt8} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt9} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt10} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt11} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt12} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>

                </div>
                {/* <!-- row 3 --> */}
                <div className="row">
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt13} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt14} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt15} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt16} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt17} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-6 col-lg-2">
                        <div className="card" style={{textAlign: "center"}}>
                            <img className="card-img-top" src={shirt18} alt="Cardimage" />
                            <div className="card-body">
                                <h3>Product</h3>
                                <h5>$20</h5>
                                <p>Lorem ipsum dolor sit amet consectetur.</p>
                                <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                                    to cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </Fragment>
    )
}

export default Shirt