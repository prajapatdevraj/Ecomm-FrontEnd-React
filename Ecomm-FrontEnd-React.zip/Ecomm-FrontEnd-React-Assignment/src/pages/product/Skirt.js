import React, { Fragment } from 'react'
import skirt1 from '../../images/Product/Women-skirt/skirt (1).webp'
import skirt2  from '../../images/Product/Women-skirt/skirt (2).webp'
import skirt3  from '../../images/Product/Women-skirt/skirt (3).webp'
import skirt4  from '../../images/Product/Women-skirt/skirt (4).webp'
import skirt5  from '../../images/Product/Women-skirt/skirt (5).webp'
import skirt6  from '../../images/Product/Women-skirt/skirt (6).webp'
import skirt7  from '../../images/Product/Women-skirt/skirt (7).webp'
import skirt8  from '../../images/Product/Women-skirt/skirt (8).webp'
import skirt9  from '../../images/Product/Women-skirt/skirt (9).webp'
import skirt10 from '../../images/Product/Women-skirt/skirt (10).webp'
import skirt11 from '../../images/Product/Women-skirt/skirt (11).webp'
import skirt12 from '../../images/Product/Women-skirt/skirt (12).webp'
import skirt13 from '../../images/Product/Women-skirt/skirt (13).webp'
import skirt14 from '../../images/Product/Women-skirt/skirt (14).webp'
import skirt15 from '../../images/Product/Women-skirt/skirt (15).webp'
import skirt16 from '../../images/Product/Women-skirt/skirt (16).webp'
import skirt17 from '../../images/Product/Women-skirt/skirt (17).webp'
import skirt18 from '../../images/Product/Women-skirt/skirt (18).webp'
function Skirt() {
  return (
    <Fragment>
        {/* <!-- heading --> */}
    <h2 style={{textAlign: "center", textShadow: "1px 1px 3px"}}>Skirt</h2>

    <div className="container productCard">
        {/* <!-- row 1 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt1} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt2} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt3} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt4} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt5} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt6} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 2 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt7} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt8} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt9} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt10} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt11} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt12} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>

        </div>
        {/* <!-- row 3 --> */}
        <div className="row">
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt13} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt14} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt15} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt16} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt17} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 col-6 col-lg-2">
                <div className="card" style={{textAlign: "center"}}>
                    <img className="card-img-top" src={skirt18} alt="Cardimage" />
                    <div className="card-body">
                        <h3>Product</h3>
                        <h5>$20</h5>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                        <button className="btn btn-warning"><span className="material-symbols-outlined">shopping_cart</span> Add
                            to cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </Fragment>
  )
}

export default Skirt