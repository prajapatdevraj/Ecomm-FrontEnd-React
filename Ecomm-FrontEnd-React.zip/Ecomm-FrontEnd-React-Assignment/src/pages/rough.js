import { Router, Routes } from 'react-router-dom';
import '../src/style.css';

// import Footer from './component/Footer';
import Contactus from './pages/Contactus';
import Home from './pages/Home';
import Login from './pages/Login';
import Cart from './pages/Cart';

// import Navbar from './component/Navbar';



// import AllProduct from './pages/product/AllProduct';
// import Allwomen from './pages/product/Allwomen';
// import Allmen from './pages/product/Allmen';

// import Pents from './pages/product/Pents';
// import Kurta from './pages/product/Kurta';
// import Saree from './pages/product/Saree';
// import Skirt from './pages/product/Skirt';
// import Shirt from './pages/product/Shirt';
// import Hoodies from './pages/product/Hoodies';
// import Kids from './pages/product/Kids';


function App() {
  return (
    <Router>
      <Routes>
        <Routes exact path="/" element={<Home />}></Routes>
        <Routes exact path="/login" element={<Login />}></Routes>
        <Routes exact path="/cart" element={<Cart />}></Routes>
        <Routes exact path="/contactus" element={<Contactus />}></Routes>
      </Routes>
    </Router>
  
      // <Router>
      //   <Routes>
      //     <Route exact path="/" element={<Home/>} ></Route>
      //     <Route exact path="/contactus" element={<Contactus/>} ></Route>
      //     <Route exact path="/login" element={<Login/>} ></Route>
      //     <Route exact path="/cart" element={<Cart/>} ></Route>
      //   </Routes>
      // </Router>

      /* <Navbar></Navbar>
      <Home></Home>
      <Login></Login>
      <Cart></Cart>
      <Contactus></Contactus> */

      /*{/* <AllProduct></AllProduct>
      <Allwomen></Allwomen>
      <Allmen></Allmen> *//*

      {/* <Hoodies></Hoodies> */
      // {/* <Shirt></Shirt> */}
      // {/* <Pents></Pents> */}
      // {/* <Kurta></Kurta> */}
      // {/* <Saree></Saree> */}
      // {/* <Skirt></Skirt> */}
      // {/* <Kids></Kids> */}
      // <Footer></Footer>*/
      


  );
}

export default App;
